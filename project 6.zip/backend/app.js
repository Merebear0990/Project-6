const express = require('express');

const app = express();

app.use(express.json());

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  next();
});

app.post('/api/auth/signup', (req, res, next) => {
  const auth signup = [
  
    {
      email: 'hello@a.com',
      password: 'hello',
    }
  
  ]
  res.status(201).json({
    message: 'Thing saved successfully'
  })
});

app.get('/api/sauces', (req, res, next) => {
  const sauces = [
    {
      _id: 'pizza',
      name: 'pepperoni',
      manufacturer: 'papa johns',
    }
  ]
  res.status(200).json(sauces);
})

// manufacturer: st,
// description!: string,
// heat: number,
// likes: number,
// dislikes: number,
// imageUrl: string,
// mainPepper: string,
// usersLiked: string[],
// usersDisliked: string[],
// userId: string,

module.exports = app;